<?php include('header.php')?>

<?php
$alert="You have enter wrong card Detail";
echo "<script type='text/javascript'>alert('$alert');</script>";
?>
<div class="top-page-headings">
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				 <ul class="breadcrumb">
    <li class="breadcrumb-item"><a href="http://52.2.212.171/Worlds_coffee/">Home</a></li>
    <li class="breadcrumb-item active"><a href="http://52.2.212.171/Worlds_coffee/index.php/Worlds_coffee/cart">Cart</a></li>
  	</ul>
			</div>
		</div>
	</div>
</div>
<section>
  <div class="middle">
  	<div class="about">
  	<div class="container">
      <div class="row cart_product">
                  <div class="text-center no_data">
            
            payment Unsuccessful...

          </div>
              </div>
  	</div>
  	</div>
  </div>
</section>


<?php include('footer.php');?>